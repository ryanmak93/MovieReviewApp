﻿namespace netflix
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.id_label = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.find_movie_tb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.find_movie_button = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.add_movie_tb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.add_movie_button = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.review_tb = new System.Windows.Forms.TextBox();
            this.find_reviews_button = new System.Windows.Forms.Button();
            this.get_reviews_tb = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.add_review_tb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rating_drop = new System.Windows.Forms.ComboBox();
            this.add_review_button = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.one_label = new System.Windows.Forms.Label();
            this.two_label = new System.Windows.Forms.Label();
            this.three_label = new System.Windows.Forms.Label();
            this.four_label = new System.Windows.Forms.Label();
            this.five_label = new System.Windows.Forms.Label();
            this.total_label = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ave_label = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ave_tb = new System.Windows.Forms.TextBox();
            this.calc_ave = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.top_movies_tb = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.movie_count_tb = new System.Windows.Forms.TextBox();
            this.show_movies_button = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.top_user_tb = new System.Windows.Forms.TextBox();
            this.show_review_button = new System.Windows.Forms.Button();
            this.user_count_tb = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.top_reviewed_tb = new System.Windows.Forms.TextBox();
            this.reviewed_movies_button = new System.Windows.Forms.Button();
            this.reviewed_movie_tb = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.exit_button = new System.Windows.Forms.Button();
            this.success_label = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.all_movies_button = new System.Windows.Forms.Button();
            this.all_movies_tb = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(6, 15);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(736, 387);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.id_label);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.find_movie_tb);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.find_movie_button);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(728, 358);
            this.tabPage4.TabIndex = 7;
            this.tabPage4.Text = "Find Movie";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id_label.Location = new System.Drawing.Point(48, 148);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(21, 20);
            this.id_label.TabIndex = 4;
            this.id_label.Text = "...";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 148);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 20);
            this.label17.TabIndex = 3;
            this.label17.Text = "ID: ";
            // 
            // find_movie_tb
            // 
            this.find_movie_tb.Location = new System.Drawing.Point(6, 45);
            this.find_movie_tb.Name = "find_movie_tb";
            this.find_movie_tb.Size = new System.Drawing.Size(279, 22);
            this.find_movie_tb.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Movie Name:";
            // 
            // find_movie_button
            // 
            this.find_movie_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.find_movie_button.Location = new System.Drawing.Point(6, 90);
            this.find_movie_button.Name = "find_movie_button";
            this.find_movie_button.Size = new System.Drawing.Size(81, 27);
            this.find_movie_button.TabIndex = 0;
            this.find_movie_button.Text = "Find";
            this.find_movie_button.UseVisualStyleBackColor = true;
            this.find_movie_button.Click += new System.EventHandler(this.find_button_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.add_movie_tb);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.add_movie_button);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(728, 358);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add Movie";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // add_movie_tb
            // 
            this.add_movie_tb.Location = new System.Drawing.Point(6, 45);
            this.add_movie_tb.Name = "add_movie_tb";
            this.add_movie_tb.Size = new System.Drawing.Size(279, 22);
            this.add_movie_tb.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Movie Name:";
            // 
            // add_movie_button
            // 
            this.add_movie_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_movie_button.Location = new System.Drawing.Point(6, 90);
            this.add_movie_button.Name = "add_movie_button";
            this.add_movie_button.Size = new System.Drawing.Size(81, 27);
            this.add_movie_button.TabIndex = 0;
            this.add_movie_button.Text = "Add";
            this.add_movie_button.UseVisualStyleBackColor = true;
            this.add_movie_button.Click += new System.EventHandler(this.add_movie_button_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.review_tb);
            this.tabPage8.Controls.Add(this.find_reviews_button);
            this.tabPage8.Controls.Add(this.get_reviews_tb);
            this.tabPage8.Controls.Add(this.label16);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(728, 358);
            this.tabPage8.TabIndex = 8;
            this.tabPage8.Text = "Get Reviews";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // review_tb
            // 
            this.review_tb.Location = new System.Drawing.Point(180, 15);
            this.review_tb.Multiline = true;
            this.review_tb.Name = "review_tb";
            this.review_tb.ReadOnly = true;
            this.review_tb.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.review_tb.Size = new System.Drawing.Size(468, 315);
            this.review_tb.TabIndex = 3;
            // 
            // find_reviews_button
            // 
            this.find_reviews_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.find_reviews_button.Location = new System.Drawing.Point(6, 90);
            this.find_reviews_button.Name = "find_reviews_button";
            this.find_reviews_button.Size = new System.Drawing.Size(81, 27);
            this.find_reviews_button.TabIndex = 2;
            this.find_reviews_button.Text = "Find";
            this.find_reviews_button.UseVisualStyleBackColor = true;
            this.find_reviews_button.Click += new System.EventHandler(this.find_reviews_button_Click);
            // 
            // get_reviews_tb
            // 
            this.get_reviews_tb.Location = new System.Drawing.Point(6, 45);
            this.get_reviews_tb.Name = "get_reviews_tb";
            this.get_reviews_tb.Size = new System.Drawing.Size(100, 22);
            this.get_reviews_tb.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(80, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Movie ID:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.add_review_tb);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.rating_drop);
            this.tabPage2.Controls.Add(this.add_review_button);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(728, 358);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Add Review";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // add_review_tb
            // 
            this.add_review_tb.Location = new System.Drawing.Point(6, 45);
            this.add_review_tb.Name = "add_review_tb";
            this.add_review_tb.Size = new System.Drawing.Size(279, 22);
            this.add_review_tb.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Movie Name:\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Rating:";
            // 
            // rating_drop
            // 
            this.rating_drop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rating_drop.FormattingEnabled = true;
            this.rating_drop.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.rating_drop.Location = new System.Drawing.Point(74, 78);
            this.rating_drop.Name = "rating_drop";
            this.rating_drop.Size = new System.Drawing.Size(62, 24);
            this.rating_drop.TabIndex = 1;
            // 
            // add_review_button
            // 
            this.add_review_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_review_button.Location = new System.Drawing.Point(6, 117);
            this.add_review_button.Name = "add_review_button";
            this.add_review_button.Size = new System.Drawing.Size(81, 27);
            this.add_review_button.TabIndex = 0;
            this.add_review_button.Text = "Add";
            this.add_review_button.UseVisualStyleBackColor = true;
            this.add_review_button.Click += new System.EventHandler(this.add_review_button_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.one_label);
            this.tabPage3.Controls.Add(this.two_label);
            this.tabPage3.Controls.Add(this.three_label);
            this.tabPage3.Controls.Add(this.four_label);
            this.tabPage3.Controls.Add(this.five_label);
            this.tabPage3.Controls.Add(this.total_label);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.ave_label);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.ave_tb);
            this.tabPage3.Controls.Add(this.calc_ave);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(728, 358);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Rating";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // one_label
            // 
            this.one_label.AutoSize = true;
            this.one_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one_label.Location = new System.Drawing.Point(38, 292);
            this.one_label.Name = "one_label";
            this.one_label.Size = new System.Drawing.Size(18, 20);
            this.one_label.TabIndex = 16;
            this.one_label.Text = "0";
            // 
            // two_label
            // 
            this.two_label.AutoSize = true;
            this.two_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two_label.Location = new System.Drawing.Point(38, 257);
            this.two_label.Name = "two_label";
            this.two_label.Size = new System.Drawing.Size(18, 20);
            this.two_label.TabIndex = 15;
            this.two_label.Text = "0";
            // 
            // three_label
            // 
            this.three_label.AutoSize = true;
            this.three_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three_label.Location = new System.Drawing.Point(38, 222);
            this.three_label.Name = "three_label";
            this.three_label.Size = new System.Drawing.Size(18, 20);
            this.three_label.TabIndex = 14;
            this.three_label.Text = "0";
            // 
            // four_label
            // 
            this.four_label.AutoSize = true;
            this.four_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four_label.Location = new System.Drawing.Point(38, 187);
            this.four_label.Name = "four_label";
            this.four_label.Size = new System.Drawing.Size(18, 20);
            this.four_label.TabIndex = 13;
            this.four_label.Text = "0";
            // 
            // five_label
            // 
            this.five_label.AutoSize = true;
            this.five_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five_label.Location = new System.Drawing.Point(38, 152);
            this.five_label.Name = "five_label";
            this.five_label.Size = new System.Drawing.Size(18, 20);
            this.five_label.TabIndex = 12;
            this.five_label.Text = "0";
            // 
            // total_label
            // 
            this.total_label.AutoSize = true;
            this.total_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_label.Location = new System.Drawing.Point(269, 117);
            this.total_label.Name = "total_label";
            this.total_label.Size = new System.Drawing.Size(18, 20);
            this.total_label.TabIndex = 11;
            this.total_label.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(13, 292);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "1:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(144, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 20);
            this.label11.TabIndex = 9;
            this.label11.Text = "Total Reviews:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 222);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 20);
            this.label10.TabIndex = 8;
            this.label10.Text = "3:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 187);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 20);
            this.label9.TabIndex = 7;
            this.label9.Text = "4:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(13, 257);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "2:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(13, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "5:";
            // 
            // ave_label
            // 
            this.ave_label.AutoSize = true;
            this.ave_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ave_label.Location = new System.Drawing.Point(87, 117);
            this.ave_label.Name = "ave_label";
            this.ave_label.Size = new System.Drawing.Size(18, 20);
            this.ave_label.TabIndex = 4;
            this.ave_label.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 117);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "Average:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "Movie Name:";
            // 
            // ave_tb
            // 
            this.ave_tb.Location = new System.Drawing.Point(6, 45);
            this.ave_tb.Name = "ave_tb";
            this.ave_tb.Size = new System.Drawing.Size(229, 22);
            this.ave_tb.TabIndex = 1;
            // 
            // calc_ave
            // 
            this.calc_ave.Location = new System.Drawing.Point(6, 84);
            this.calc_ave.Name = "calc_ave";
            this.calc_ave.Size = new System.Drawing.Size(81, 27);
            this.calc_ave.TabIndex = 0;
            this.calc_ave.Text = "Calculate";
            this.calc_ave.UseVisualStyleBackColor = true;
            this.calc_ave.Click += new System.EventHandler(this.calc_ave_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.top_movies_tb);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.movie_count_tb);
            this.tabPage5.Controls.Add(this.show_movies_button);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(728, 358);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Top Movies";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // top_movies_tb
            // 
            this.top_movies_tb.Location = new System.Drawing.Point(180, 15);
            this.top_movies_tb.Multiline = true;
            this.top_movies_tb.Name = "top_movies_tb";
            this.top_movies_tb.ReadOnly = true;
            this.top_movies_tb.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.top_movies_tb.Size = new System.Drawing.Size(468, 315);
            this.top_movies_tb.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(145, 20);
            this.label13.TabIndex = 2;
            this.label13.Text = "Number of Movies";
            // 
            // movie_count_tb
            // 
            this.movie_count_tb.Location = new System.Drawing.Point(6, 45);
            this.movie_count_tb.Name = "movie_count_tb";
            this.movie_count_tb.Size = new System.Drawing.Size(100, 22);
            this.movie_count_tb.TabIndex = 1;
            // 
            // show_movies_button
            // 
            this.show_movies_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_movies_button.Location = new System.Drawing.Point(6, 90);
            this.show_movies_button.Name = "show_movies_button";
            this.show_movies_button.Size = new System.Drawing.Size(130, 27);
            this.show_movies_button.TabIndex = 0;
            this.show_movies_button.Text = "Show Movies";
            this.show_movies_button.UseVisualStyleBackColor = true;
            this.show_movies_button.Click += new System.EventHandler(this.show_movies_button_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.top_user_tb);
            this.tabPage6.Controls.Add(this.show_review_button);
            this.tabPage6.Controls.Add(this.user_count_tb);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(728, 358);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Top Users";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // top_user_tb
            // 
            this.top_user_tb.Location = new System.Drawing.Point(180, 15);
            this.top_user_tb.Multiline = true;
            this.top_user_tb.Name = "top_user_tb";
            this.top_user_tb.ReadOnly = true;
            this.top_user_tb.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.top_user_tb.Size = new System.Drawing.Size(468, 315);
            this.top_user_tb.TabIndex = 3;
            // 
            // show_review_button
            // 
            this.show_review_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_review_button.Location = new System.Drawing.Point(6, 90);
            this.show_review_button.Name = "show_review_button";
            this.show_review_button.Size = new System.Drawing.Size(130, 27);
            this.show_review_button.TabIndex = 2;
            this.show_review_button.Text = "Show Reviews";
            this.show_review_button.UseVisualStyleBackColor = true;
            this.show_review_button.Click += new System.EventHandler(this.show_review_button_Click);
            // 
            // user_count_tb
            // 
            this.user_count_tb.Location = new System.Drawing.Point(6, 45);
            this.user_count_tb.Name = "user_count_tb";
            this.user_count_tb.Size = new System.Drawing.Size(100, 22);
            this.user_count_tb.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(155, 20);
            this.label14.TabIndex = 0;
            this.label14.Text = "Number of Reviews";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.top_reviewed_tb);
            this.tabPage7.Controls.Add(this.reviewed_movies_button);
            this.tabPage7.Controls.Add(this.reviewed_movie_tb);
            this.tabPage7.Controls.Add(this.label15);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(728, 358);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Reviewed Movies";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // top_reviewed_tb
            // 
            this.top_reviewed_tb.Location = new System.Drawing.Point(180, 15);
            this.top_reviewed_tb.Multiline = true;
            this.top_reviewed_tb.Name = "top_reviewed_tb";
            this.top_reviewed_tb.ReadOnly = true;
            this.top_reviewed_tb.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.top_reviewed_tb.Size = new System.Drawing.Size(468, 315);
            this.top_reviewed_tb.TabIndex = 3;
            // 
            // reviewed_movies_button
            // 
            this.reviewed_movies_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reviewed_movies_button.Location = new System.Drawing.Point(6, 90);
            this.reviewed_movies_button.Name = "reviewed_movies_button";
            this.reviewed_movies_button.Size = new System.Drawing.Size(130, 27);
            this.reviewed_movies_button.TabIndex = 2;
            this.reviewed_movies_button.Text = "Show Movies";
            this.reviewed_movies_button.UseVisualStyleBackColor = true;
            this.reviewed_movies_button.Click += new System.EventHandler(this.reviewed_movies_button_Click);
            // 
            // reviewed_movie_tb
            // 
            this.reviewed_movie_tb.Location = new System.Drawing.Point(6, 45);
            this.reviewed_movie_tb.Name = "reviewed_movie_tb";
            this.reviewed_movie_tb.Size = new System.Drawing.Size(100, 22);
            this.reviewed_movie_tb.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "Number of Movies";
            // 
            // exit_button
            // 
            this.exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.Location = new System.Drawing.Point(667, 411);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(75, 33);
            this.exit_button.TabIndex = 3;
            this.exit_button.Text = "Exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // success_label
            // 
            this.success_label.AutoSize = true;
            this.success_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.success_label.Location = new System.Drawing.Point(12, 411);
            this.success_label.Name = "success_label";
            this.success_label.Size = new System.Drawing.Size(21, 20);
            this.success_label.TabIndex = 4;
            this.success_label.Text = "...";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.all_movies_tb);
            this.tabPage9.Controls.Add(this.all_movies_button);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(728, 358);
            this.tabPage9.TabIndex = 9;
            this.tabPage9.Text = "All Movies";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // all_movies_button
            // 
            this.all_movies_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.all_movies_button.Location = new System.Drawing.Point(16, 16);
            this.all_movies_button.Name = "all_movies_button";
            this.all_movies_button.Size = new System.Drawing.Size(81, 27);
            this.all_movies_button.TabIndex = 0;
            this.all_movies_button.Text = "Find";
            this.all_movies_button.UseVisualStyleBackColor = true;
            this.all_movies_button.Click += new System.EventHandler(this.all_movies_button_Click);
            // 
            // all_movies_tb
            // 
            this.all_movies_tb.Location = new System.Drawing.Point(16, 68);
            this.all_movies_tb.Multiline = true;
            this.all_movies_tb.Name = "all_movies_tb";
            this.all_movies_tb.ReadOnly = true;
            this.all_movies_tb.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.all_movies_tb.Size = new System.Drawing.Size(692, 275);
            this.all_movies_tb.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 449);
            this.Controls.Add(this.success_label);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Movie Reviewer";
            this.tabControl1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button add_movie_button;
        private System.Windows.Forms.Button add_review_button;
        private System.Windows.Forms.TextBox ave_tb;
        private System.Windows.Forms.Button calc_ave;
        private System.Windows.Forms.TextBox add_movie_tb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox add_review_tb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox rating_drop;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label ave_label;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label one_label;
        private System.Windows.Forms.Label two_label;
        private System.Windows.Forms.Label three_label;
        private System.Windows.Forms.Label four_label;
        private System.Windows.Forms.Label five_label;
        private System.Windows.Forms.Label total_label;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox movie_count_tb;
        private System.Windows.Forms.Button show_movies_button;
        private System.Windows.Forms.Button show_review_button;
        private System.Windows.Forms.TextBox user_count_tb;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox reviewed_movie_tb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button reviewed_movies_button;
        private System.Windows.Forms.TextBox top_movies_tb;
        private System.Windows.Forms.TextBox top_user_tb;
        private System.Windows.Forms.TextBox top_reviewed_tb;
        private System.Windows.Forms.Label success_label;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox find_movie_tb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button find_movie_button;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox review_tb;
        private System.Windows.Forms.Button find_reviews_button;
        private System.Windows.Forms.TextBox get_reviews_tb;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button all_movies_button;
        private System.Windows.Forms.TextBox all_movies_tb;

    }
}

