﻿//
// BusinessTier:  business logic, acting as interface between UI and data store.
//

using System;
using System.Collections.Generic;
using System.Data;


namespace BusinessTier
{

  //
  // Business:
  //
  public class Business
  {
    //
    // Fields:
    //
    private string _DBFile;
    private DataAccessTier.Data datatier;


    //
    // Constructor:
    //
    public Business(string DatabaseFilename)
    {
      _DBFile = DatabaseFilename;

      datatier = new DataAccessTier.Data(DatabaseFilename);
    }


    //
    // TestConnection:
    //
    // Returns true if we can establish a connection to the database, false if not.
    //
    public bool TestConnection()
    {
      return datatier.TestConnection();
    }


    //
    // GetMovie:
    //
    // Retrieves Movie object based on MOVIE ID; returns null if movie is not
    // found.
    //
    public Movie GetMovie(int MovieID)
    {
        string sql = String.Format("SELECT MovieName FROM Movies WHERE MovieID = {0};", MovieID);
        string movieName = datatier.ExecuteScalarQuery(sql).ToString();
        if (movieName == null)
            return null;
        Movie newMovie = new Movie(MovieID,movieName);

        return newMovie;
    }


    //
    // GetMovie:
    //
    // Retrieves Movie object based on MOVIE NAME; returns null if movie is not
    // found.
    //
    public Movie GetMovie(string MovieName)
    {
        string sql = String.Format("SELECT MovieID FROM Movies WHERE MovieName = '{0}';", MovieName);
        object result = datatier.ExecuteScalarQuery(sql);
        if (result == null)
            return null;

        int movieID = Convert.ToInt32(result);
        Movie newMovie = new Movie(movieID,MovieName);
        return newMovie;
    }


    //
    // AddMovie:
    //
    // Adds the movie, returning a Movie object containing the name and the 
    // movie's id.  If the add failed, null is returned.
    //
    public Movie AddMovie(string MovieName)
    {
        string sql = String.Format(
            "INSERT INTO Movies (MovieName) VALUES('{0}'); SELECT MovieID FROM Movies WHERE MovieID = SCOPE_IDENTITY();", MovieName);
        object result = datatier.ExecuteScalarQuery(sql);
        if (result == null)
            return null;

        int movieID = Convert.ToInt32(result);
        Movie newMovie = new Movie(movieID,MovieName);
        return newMovie;
    }


    //
    // AddReview:
    //
    // Adds review based on MOVIE ID, returning a Review object containing
    // the review, review's id, etc.  If the add failed, null is returned.
    //
    public Review AddReview(int MovieID, int UserID, int Rating)
    {
        string sql = String.Format(
            "INSERT INTO Reviews (MovieID, UserId, Rating) VALUES ({0},{1},{2}); SELECT ReviewID FROM Reviews WHERE ReviewID = SCOPE_IDENTITY();", MovieID,
                    UserID, Rating);
        object result = datatier.ExecuteScalarQuery(sql);
        if (result == null)
            return null;
        int reviewID = Convert.ToInt32(result);
        Review newReview = new Review(reviewID,MovieID,UserID,Rating);
        return newReview;
    }


    //
    // GetMovieDetail:
    //
    // Given a MOVIE ID, returns detailed information about this movie --- all
    // the reviews, the total number of reviews, average rating, etc.  If the 
    // movie cannot be found, null is returned.
    //
    public MovieDetail GetMovieDetail(int MovieID)
    {        
        string sql = String.Format(
@"SELECT MovieName, COUNT(Movies.MovieID), ROUND(AVG(CAST(Rating AS Float)), 2) FROM 
Movies INNER JOIN Reviews ON Movies.MovieID = Reviews.MovieID
WHERE Movies.MovieID = {0}
GROUP BY MovieName;", MovieID);
        DataSet ds = datatier.ExecuteNonScalarQuery(sql);
        if (ds == null)
            return null;
        //create datatable
        DataTable dt = ds.Tables["TABLE"];

        //get individual values from the datatable
        int id = MovieID;
        string name = dt.Rows[0].ItemArray[0].ToString();
        Movie movie = new Movie(id,name);
        int count = Convert.ToInt32(dt.Rows[0].ItemArray[1]);
        double avg = Convert.ToDouble(dt.Rows[0].ItemArray[2]);
        //get reviews for movie
        string sql2 = String.Format(
@"SELECT ReviewID, UserID, Rating FROM Reviews
WHERE MovieID = {0};", MovieID);
        DataSet ds2 = datatier.ExecuteNonScalarQuery(sql2);
        DataTable dt2 = ds2.Tables["TABLE"];  
        //put reviews in a list
        List<Review> reviews = new List<Review>();
        foreach(DataRow row in dt2.Rows)
        {
            int ReviewID = Convert.ToInt32(row.ItemArray[0]);
            int UserID = Convert.ToInt32(row.ItemArray[1]);
            int Rating = Convert.ToInt32(row.ItemArray[2]);
            Review review = new Review(ReviewID, MovieID, UserID, Rating);
            reviews.Add(review);
        }
        MovieDetail moviedetail = new MovieDetail(movie,avg,count,reviews);
        return moviedetail;
    }


    //
    // GetUserDetail:
    //
    // Given a USER ID, returns detailed information about this user --- all
    // the reviews submitted by this user, the total number of reviews, average 
    // rating given, etc.  If the user cannot be found, null is returned.
    //
    public UserDetail GetUserDetail(int UserID)
    {
        string sql = String.Format(
@"SELECT COUNT(UserID), ROUND(AVG(CAST(Rating AS Float)), 2) FROM Reviews
WHERE UserID = {0};", UserID);
        DataSet ds = datatier.ExecuteNonScalarQuery(sql);
        if (ds == null)
            return null;

        DataTable dt = ds.Tables["TABLE"];  
        string sql2 = String.Format(
@"SELECT ReviewID, MovieId, Rating FROM Reviews
WHERE UserID = {0};", UserID);
        DataSet ds2 = datatier.ExecuteNonScalarQuery(sql2);
        DataTable dt2 = ds2.Tables["TABLE"];  
        int count = Convert.ToInt32(dt.Rows[0].ItemArray[0]);
        double avg = Convert.ToInt32(dt.Rows[0].ItemArray[1]); ;
        User user = new User(UserID);
        List<Review> reviews = new List<Review>();
        foreach(DataRow row in dt2.Rows)
        {
            int ReviewID = Convert.ToInt32(row.ItemArray[0]);
            int MovieID = Convert.ToInt32(row.ItemArray[1]);
            int Rating = Convert.ToInt32(row.ItemArray[2]);
            Review review = new Review(ReviewID, MovieID, UserID, Rating);
            reviews.Add(review);
        }
        UserDetail userdetail = new UserDetail(user,avg,count,reviews);
        return userdetail;
        
    }


    //
    // GetTopMoviesByAvgRating:
    //
    // Returns the top N movies in descending order by average rating.  If two
    // movies have the same rating, the movies are presented in ascending order
    // by name.  If N < 1, an EMPTY LIST is returned.
    //
    public IReadOnlyList<Movie> GetTopMoviesByAvgRating(int N)
    {
      List<Movie> movies = new List<Movie>();

      string sql = String.Format(
@"SELECT TOP {0} Movies.MovieID, MovieName FROM Movies
INNER JOIN
(
SELECT MovieID, ROUND(AVG(CAST(Rating AS Float)), 2) as AvgRating
FROM Reviews
GROUP BY MovieID
) TEMP
ON TEMP.MovieID = Movies.MovieID
ORDER BY AvgRating DESC, MovieName ASC;",
                                        N);
      DataSet ds = datatier.ExecuteNonScalarQuery(sql);
      DataTable dt = ds.Tables["TABLE"];
      foreach (DataRow row in dt.Rows)
      {
          int id = Convert.ToInt32(row.ItemArray[0]);
          string name = row.ItemArray[1].ToString();
          movies.Add(new Movie(id,name));
      }
      
      return movies;
    }


    //
    // GetTopMoviesByNumReviews
    //
    // Returns the top N movies in descending order by number of reviews.  If two
    // movies have the same number of reviews, the movies are presented in ascending
    // order by name.  If N < 1, an EMPTY LIST is returned.
    //
    public IReadOnlyList<Movie> GetTopMoviesByNumReviews(int N)
    {
      List<Movie> movies = new List<Movie>();

      string sql = String.Format(
@"SELECT TOP {0} Movies.MovieID, MovieName FROM Movies
INNER JOIN
(
SELECT MovieID, COUNT(MovieID) as ReviewCount
FROM Reviews
GROUP BY MovieID
) TEMP
ON TEMP.MovieID = Movies.MovieID
ORDER BY ReviewCount DESC, MovieName ASC;",
                                          N);
        DataSet ds = datatier.ExecuteNonScalarQuery(sql);
        DataTable dt = ds.Tables["TABLE"];
        foreach (DataRow row in dt.Rows)
        {
            int id = Convert.ToInt32(row.ItemArray[0]);
            string name = row.ItemArray[1].ToString();
            movies.Add(new Movie(id, name));
        }
        return movies;
    }


    //
    // GetTopUsersByNumReviews
    //
    // Returns the top N users in descending order by number of reviews.  If two
    // users have the same number of reviews, the users are presented in ascending
    // order by user id.  If N < 1, an EMPTY LIST is returned.
    //
    public IReadOnlyList<User> GetTopUsersByNumReviews(int N)
    {
      List<User> users = new List<User>();

      string sql = String.Format(
@"SELECT TOP {0} UserID 
FROM Reviews
GROUP BY UserID
ORDER BY COUNT(UserID) DESC, UserID ASC;",
                                         N);
      DataSet ds = datatier.ExecuteNonScalarQuery(sql);
      DataTable dt = ds.Tables["TABLE"];
        //put users in user list
      foreach (DataRow row in dt.Rows)
      {
          int id = Convert.ToInt32(row.ItemArray[0]);
          users.Add(new User(id));
      }
      
      return users;
    }

      //
      //Get List of All Movies
      //
      //Returns list of all Moveis

    public IReadOnlyList<Movie> GetAllMovies()
    {
        List<Movie> movies = new List<Movie>();
        //get all movies in alpha order
        string sql = String.Format("SELECT MovieID, MovieName FROM Movies ORDER BY MovieName ASC;");
        DataSet ds = datatier.ExecuteNonScalarQuery(sql);
        DataTable dt = ds.Tables["TABLE"];
        //put movies in movie list
        foreach (DataRow row in dt.Rows)
        {
            int id = Convert.ToInt32(row.ItemArray[0]);
            string name = row.ItemArray[1].ToString();
            movies.Add(new Movie(id, name));
        }
        return movies;
    }

  }//class

}//namespace
