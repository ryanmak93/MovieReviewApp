﻿// Ryan Mak
// UIC
// CS341
// Fall 2014
// Homework 7
// N Tier Netflix Movie Analyzer

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace netflix
{
    public partial class Form1 : Form
    {
        BusinessTier.Business bTier = new BusinessTier.Business("netflix.mdf");

        public Form1()
        {
            InitializeComponent();            
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            //close app
            this.Close();
        }

        public void success()
        { //to switch between success and fail
            success_label.Text = "SUCCESS! ";
        }

        public void success(string message)
        {
            success_label.Text = "SUCCESS!" + message;
        }

        public void failed(string message)
        { //to switch between success and fail
            success_label.Text = "FAILED: " + message;
        }

        
        public int get_rating_count(int rating, BusinessTier.MovieDetail moviedetail)//get count of reviews for a specified rating for given movieid
        {
            int reviewcount = 0;
            foreach(BusinessTier.Review review in moviedetail.Reviews)
            {
                if (review.Rating == rating)
                    reviewcount++;
            }
            
            return reviewcount;
        }
        
        public double get_avg_rating(int movieid)
        {
            BusinessTier.MovieDetail moviedetail = bTier.GetMovieDetail(movieid);
            return Math.Round(moviedetail.AvgRating,2);
        }

        public double get_num_reviews(int movieid)
        {
            BusinessTier.MovieDetail moviedetail = bTier.GetMovieDetail(movieid);
            return moviedetail.NumReviews;
        }

        public int get_review_count(int userid)
        {
            BusinessTier.UserDetail userdetail = bTier.GetUserDetail(userid);
            return userdetail.NumReviews;
        }

  /*--------------------------------------------BUTTON HANDLERS--------------------------------------------------------------------------------*/
        private void find_button_Click(object sender, EventArgs e)
        {
            string moviename = find_movie_tb.Text;
            BusinessTier.Movie movie = bTier.GetMovie(moviename);
            if(movie == null)
            {
                failed("Movie Not Found.");
            }
            else
            {
                success();
                id_label.Text = movie.MovieID.ToString();
            }
        }  
        
        private void add_movie_button_Click(object sender, EventArgs e)
        {
            string moviename = add_movie_tb.Text;
            BusinessTier.Movie movie = bTier.GetMovie(moviename);
            if (movie != null)//if movie already exists, fail
                failed("Movie Already Exists");
            else
            {
                BusinessTier.Movie newmovie = bTier.AddMovie(moviename);
                string success_string = String.Format("Movie ID: {0}", newmovie.MovieID);
                success(success_string);
            }
        }

        private void find_reviews_button_Click(object sender, EventArgs e)
        {
            int movieid = Convert.ToInt32(get_reviews_tb.Text);
            BusinessTier.MovieDetail moviedetail = bTier.GetMovieDetail(movieid);
            if(moviedetail == null)
                failed("Movie Not Found");
            else
            {
                success();
                BusinessTier.Movie movie = bTier.GetMovie(movieid);
                string review_string = movie.MovieName + Environment.NewLine;
                foreach (BusinessTier.Review review in moviedetail.Reviews) //loop to create string
                {
                    review_string = review_string + "ReviewID: " + review.ReviewID + " | UserID: " + review.UserID +
                        " | Rating: " + review.Rating +Environment.NewLine;
                }
                review_tb.Text = review_string;
            }
        }   

        private void add_review_button_Click(object sender, EventArgs e)
        {
            string moviename = add_review_tb.Text;
            BusinessTier.Movie movie = bTier.GetMovie(moviename);
            if (movie != null)//if movie doesnt exist, fail
            {
                int rating = Convert.ToInt32(rating_drop.SelectedItem);
                int userID = 123;
                BusinessTier.Review review = bTier.AddReview(movie.MovieID,userID,rating);
                string success_string = String.Format("Review ID: {0}", review.ReviewID);
                success(success_string);
            }       
            else
                failed("Movie Not Found");
        }

        private void calc_ave_Click(object sender, EventArgs e)
        { 
            string moviename = ave_tb.Text;
            BusinessTier.Movie movie = bTier.GetMovie(moviename);
            //find movie, if not found, failed
           if(movie != null)
            {
                BusinessTier.MovieDetail moviedetail = bTier.GetMovieDetail(movie.MovieID);

                //average rating
                double ave = Math.Round(moviedetail.AvgRating,2);
                ave_label.Text = ave.ToString();

                //total reviews
                int total_reviews = moviedetail.NumReviews;
                total_label.Text = total_reviews.ToString();

                //number of reviews for each rating
                int rate_5 = get_rating_count(5, moviedetail);
                int rate_4 = get_rating_count(4, moviedetail);
                int rate_3 = get_rating_count(3, moviedetail);
                int rate_2 = get_rating_count(2, moviedetail);
                int rate_1 = get_rating_count(1, moviedetail);
                five_label.Text = rate_5.ToString();
                four_label.Text = rate_4.ToString();
                three_label.Text = rate_3.ToString();
                two_label.Text = rate_2.ToString();
                one_label.Text = rate_1.ToString();
            }
            else
                failed("Movie Not Found"); 
        }

        private void show_movies_button_Click(object sender, EventArgs e)
        {     
            int movie_count = Convert.ToInt32(movie_count_tb.Text);
            IReadOnlyList<BusinessTier.Movie> topmovies = bTier.GetTopMoviesByAvgRating(movie_count);
            string top_movie_string = null;
            foreach(BusinessTier.Movie movie in topmovies)       
                top_movie_string = top_movie_string + "Title: " + movie.MovieName
                  + " | "  + "Rating: " + get_avg_rating(movie.MovieID) + Environment.NewLine;
            top_movies_tb.Text = top_movie_string;
        }

        private void show_review_button_Click(object sender, EventArgs e)
        {
            int user_count = Convert.ToInt32(user_count_tb.Text);
            IReadOnlyList<BusinessTier.User> topusers = bTier.GetTopUsersByNumReviews(user_count);
            string top_user_string = null;
            foreach (BusinessTier.User user in topusers)
                top_user_string = top_user_string + "UserID: " + user.UserID
                  + " | " + "Reviews: " + get_review_count(user.UserID) + Environment.NewLine;
            top_user_tb.Text = top_user_string;
        }

        private void reviewed_movies_button_Click(object sender, EventArgs e)
        {
            int movie_count = Convert.ToInt32(reviewed_movie_tb.Text);
            IReadOnlyList<BusinessTier.Movie> topmovies = bTier.GetTopMoviesByNumReviews(movie_count);
            string reviewed_movie_string = null;
            foreach (BusinessTier.Movie movie in topmovies)
                reviewed_movie_string = reviewed_movie_string + "Title: " + movie.MovieName
                  + " | " + "Rating: " + get_num_reviews(movie.MovieID) + Environment.NewLine;
            top_reviewed_tb.Text = reviewed_movie_string;
        }

        private void all_movies_button_Click(object sender, EventArgs e)
        {
            IReadOnlyList<BusinessTier.Movie> allmovies = bTier.GetAllMovies();
            string movies_string = null;
            foreach (BusinessTier.Movie movie in allmovies)
                movies_string = movies_string + movie.MovieName + Environment.NewLine;
            all_movies_tb.Text = movies_string;
            

            success();
        }
         
    }
}
